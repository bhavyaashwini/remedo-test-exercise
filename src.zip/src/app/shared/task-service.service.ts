import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService {

  constructor(private http : HttpClient) { }

  public allList(){
    console.log("lal", this.allList);
   return  this.http.get("https://jsonplaceholder.typicode.com/albums");
  }
}
