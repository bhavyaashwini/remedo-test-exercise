import { Component, OnInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';

import { TaskServiceService } from '../shared/task-service.service';
import { TaskList } from '../tasklist.model';

import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatSort, SortDirection} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  ELEMENT_DATA: TaskList[];
  displayedColumns: string[] = ['id', 'userId', 'title'];
  dataSource = new MatTableDataSource<TaskList>(this.ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
 

  constructor(private taskService: TaskServiceService) { }
 
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  ngOnInit() {
    this.getAllList();
  }
public getAllList(){
  let resp= this.taskService.allList();
  console.log("list", this.dataSource.data);
  resp.subscribe(report => this.dataSource.data = report as  TaskList[]);
  // this.taskService.allList().subscribe(res=>{
  //   this.dataSource= res;
  // })
}

}
