export interface TaskList{
    id: any;
    userId:any;
    title: string;
}